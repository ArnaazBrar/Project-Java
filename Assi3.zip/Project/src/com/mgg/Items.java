package com.mgg;

/*
 * Sales class creates object for any
 * sales that take place
 * 
 */

public abstract class Items {
	
	private String itemCode;
	private String name;
	private String type;
	
	public Items(String itemCode, String type, String name) {
		super();
		this.itemCode = itemCode;
		this.type = type;
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public String getCode() {
		return itemCode;
	}

	public String getName() {
		return name;
	}
	
	public abstract double getCost();
	
	public abstract double getTaxRate();
	
	public double getTotal() {
		return this.getTax() + this.getCost();	
	}
	
	public double getTax() {
		return this.getTaxRate() * this.getCost();
	}
	
	@Override
	public String toString() {
		return "Sales [itemCode=" + itemCode +  ", name=" + name + "]";
	}
	

}