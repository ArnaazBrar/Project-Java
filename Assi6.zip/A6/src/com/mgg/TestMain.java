package com.mgg;

public class TestMain {
	
	public static void main(String args[]) {
		
		//SalesData.addStore("qkdw4k", "7egf53","Goniana Road", "Bathinda", "Punjab", "151001", "India");
		//SalesData.addEmail("qkdwq0", "aseesjotbrar@gmail.com");
		//SalesData.addItem("afmrk9r","SB","Hotstar",13.99);
		//SalesData.addSale("afjiqe","rjuhf4","73h77g","7egf53");
	}

}
